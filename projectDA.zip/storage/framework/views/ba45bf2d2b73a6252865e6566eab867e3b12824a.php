        <!-- Footer Section Start -->
        <footer class="footer--section">
            <!-- Footer Widgets Start -->
            <div class="footer--widgets pd--30-0 bg--color-2" style="background-color: #1d1d1d;">
                <div class="container">
                    <div class="row AdjustRow">
                        <div class="col-md-3 col-xs-6 col-xxs-12 ptop--30 pbottom--30">
                            <!-- Widget Start -->
                            <div class="widget">
                                <div class="widget--title">
                                    <h2 class="h4"><?php echo app('translator')->get('lang.gioithieu'); ?></h2>

                                    <i class="icon fa fa-exclamation"></i>
                                </div>

                                <!-- About Widget Start -->
                                <div class="about--widget">
                                    <div class="content">
                                        <p><?php echo app('translator')->get('lang.gioithieu1'); ?></p>
                                    </div>
                                </div>
                                <!-- About Widget End -->
                            </div>
                            <!-- Widget End -->
                        </div>

                        <div class="col-md-3 col-xs-6 col-xxs-12 ptop--30 pbottom--30">
                            <!-- Widget Start -->
                            <div class="widget">
                                <div class="widget--title">
                                    <h2 class="h4"><?php echo app('translator')->get('lang.lienhe'); ?></h2>

                                    <i class="icon fa fa-user-o"></i>
                                </div>

                                <!-- Links Widget Start -->
                                <div class="links--widget">

                                    <ul class="nav">
                                        <li>
                                            <i class="fa fa-map"></i>
                                            <span>143/C, Fake Street, Melborne, Australia</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-envelope-o"></i>
                                            <a href="mailto:example@example.com">example@example.com</a>
                                        </li>
                                        <li>
                                            <i class="fa fa-phone"></i>
                                            <a href="tel:+123456789">+123 456 (789)</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Links Widget End -->
                            </div>
                            <!-- Widget End -->
                        </div>


                        <div class="col-md-3 col-xs-6 col-xxs-12 ptop--30 pbottom--30">
                            <!-- Widget Start -->
                            <div class="widget">
                                <div class="widget--title">
                                    <h2 class="h4"><?php echo app('translator')->get('lang.typelist'); ?></h2>

                                    <i class="icon fa fa-expand"></i>
                                </div>

                                <!-- Links Widget Start -->
                                <div class="links--widget">
                                    <ul class="nav">
                                        <?php $__currentLoopData = $typeID; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url('type/'.$typ->slug_typ)); ?>"
                                                class="fa-angle-right"><?php echo e($typ->typName); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <!-- Links Widget End -->
                            </div>
                            <!-- Widget End -->
                        </div>
                        <!-- Subscribe Widget Start -->
                        <div class="col-md-3 col-xs-6 col-xxs-12 ptop--30 pbottom--30">
                            <div class="widget">
                                <div class="widget--title">
                                    <h2 class="h4"><?php echo app('translator')->get('lang.letter'); ?></h2>
                                    <i class="icon fa fa-envelope-open-o"></i>
                                    <p><?php echo e(session('message')); ?></p>
                                </div>

                                <!-- Links Widget Start -->
                                <form action="<?php echo e(url('letter')); ?>" method="get">
                                    <?php if(!Auth::check()): ?>
                                    <div class="links--widget">

                                        <ul class="nav">
                                            <li>
                                                <a href="<?php echo e(url('login')); ?>"><?php echo app('translator')->get('lang.dangnhap'); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <?php else: ?>
                                    <div class="input-group">
                                        <input type="text" name="content" placeholder="<?php echo app('translator')->get('lang.nhap'); ?>"
                                            class="form-control" autocomplete="off" required>
                                        <input type="hidden" name="email" value="<?php echo e(Auth::user()->email); ?>" />
                                        <input type="hidden" name="name" value="<?php echo e(Auth::user()->name); ?>" />

                                        <div class="input-group-btn">
                                            <button type="submit" class="btn btn-lg btn-default active"><i
                                                    class="fa fa-paper-plane-o"></i></button>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="status"></div>
                                </form>
                                <!-- Links Widget End -->
                            </div>
                        </div>
                        <!-- Subscribe Widget End -->

                    </div>
                </div>
            </div>
            <!-- Footer Widgets End -->
        </footer>
        <!-- Footer Section End -->
        </div>
        <!-- Wrapper End -->

        <!-- Back To Top Button Start -->
        <div id="backToTop">
            <a href="#"><i class="fa fa-angle-double-up"></i></a>
        </div>
        <!-- Back To Top Button End --><?php /**PATH C:\xampp\htdocs\projectDA\resources\views/layout/footer.blade.php ENDPATH**/ ?>