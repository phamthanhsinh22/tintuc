<!-- Preloader Start -->
<div id="preloader">
        <div class="preloader bg--color-1--b" data-preloader="1">
            <div class="preloader--inner"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Wrapper Start -->
    <div class="wrapper">
        <!-- Header Section Start -->
        <header class="header--section header--style-1">

            <!-- Header Mainbar Start -->
            <div class="header--mainbar">
                <div class="container">
                    <!-- Header Logo Start -->
                    <div class="header--logo float--left float--sm-none text-sm-center">
                        <h1 class="h1">
                            <a href="<?php echo e(URL('index')); ?>" class="btn-link">
                                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="USNews Logo">
                                <span class="hidden">USNews Logo</span>
                            </a>
                        </h1>
                    </div>
                    <!-- Header Logo End -->
            <!-- Header Topbar Start -->
            <div class="header--topbar bg--color-2">
                <div class="container">
                    <div class="float--right float--xs-none text-xs-center" style="margin-top: 20px;">
                        <!-- Header Topbar Action Start -->
                        <ul class="header--topbar-action nav">
                            <?php if(!Auth::check()): ?>
                                <li><a href="<?php echo e(URL('login')); ?>"><i class="fa fm fa-user-o"></i><?php echo app('translator')->get('lang.dangnhap'); ?></a></li>
                            <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fm fa-user-o"></i><?php echo e(Auth::user()->name); ?><i class="fa flm fa-angle-down"></i></a>

                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(URL('logout')); ?>"><?php echo app('translator')->get('lang.dangxuat'); ?></a></li>
                                </ul>
                            </li>
                            <?php endif; ?>
                        </ul>
                        <!-- Header Topbar Action End -->
                        
                        <!-- Header Topbar Language Start -->
                        <ul class="header--topbar-lang nav">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fm fa-language"></i><?php echo app('translator')->get('lang.ngonngu'); ?><i class="fa flm fa-angle-down"></i></a>

                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(url('lang/en')); ?>"><?php echo app('translator')->get('lang.TA'); ?></a></li>
                                    <li><a href="<?php echo e(url('lang/vi')); ?>"><?php echo app('translator')->get('lang.TV'); ?></a></li>
                                </ul>
                            </li>
                        </ul>
                        <!-- Header Topbar Language End -->

                        <!-- Header Topbar Social Start -->
                        <ul class="header--topbar-social nav hidden-sm hidden-xxs">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                        <!-- Header Topbar Social End -->
                    </div>
                </div>
            </div>
            <!-- Header Topbar End -->
                </div>
            </div>
            <!-- Header Mainbar End -->

            <!-- Header Navbar Start -->
            <div class="header--navbar navbar bd--color-1 bg--color-1" data-trigger="sticky">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#headerNav" aria-expanded="false" aria-controls="headerNav">
                            <span class="sr-only">Toggle Navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div id="headerNav" class="navbar-collapse collapse float--left">
                        <!-- Header Menu Links Start -->
                        <ul class="header--menu-links nav navbar-nav" data-trigger="hoverIntent">
                        <li>
                                <a href="<?php echo e(URL('index')); ?>"><?php echo app('translator')->get('lang.home'); ?></a>
                        </li>
                        <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if($cat->Active==1): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($cat->catName); ?><i class="fa flm fa-angle-down"></i></a>
                              
                                <ul class="dropdown-menu">
                                  <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cat->id == $typ->category_id && $typ->Active==1): ?>
                                    <li><a href="<?php echo e(url('type/'.$typ->slug_typ)); ?>"><?php echo e($typ->typName); ?></a></li>
                                    <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </ul>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <!-- Header Menu Links End -->
                    </div>

                    <!-- Header Search Form Start -->
                    <form action="<?php echo e(URL('search')); ?>" class="header--search-form float--right" data-form="validate" method="post">
                    <?php echo e(csrf_field()); ?>

                        <input type="search" name="keyword_submit" placeholder="<?php echo app('translator')->get('lang.search'); ?>" class="header--search-control form-control" required>

                        <button type="submit" class="header--search-btn btn"><i class="header--search-icon fa fa-search"></i></button>
                    </form>
                    <!-- Header Search Form End -->
                </div>
            </div>
            <!-- Header Navbar End -->
        </header>
        <!-- Header Section End --><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projectDA/resources/views/layout/header.blade.php ENDPATH**/ ?>