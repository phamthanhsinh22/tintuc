<?php

return [

    'home' => 'Trang chủ',
    'dangnhap' => 'Đăng nhập/Đăng ký',
    'dangxuat' => 'Đăng xuất',
    'ngonngu' => 'Ngôn ngữ',
    'TA' => 'Tiếng Anh',
    'TV' => 'Tiếng Việt',
    'search' => 'Tìm kiếm...',
    'featured' => 'Tin tức nổi bật',
    'popular' => 'Phổ biến nhất',
    'hot' => 'Tin tức nóng',
    'trending' => 'Tin tức xu hướng',
    'watched' => 'Xem nhiều nhất',
    'update' => 'Mới cập nhật',
    'gioithieu' => 'Giới thiệu',
    'gioithieu1' => 'Chúng tôi luôn mang đến những tin tức một cách chân thực và nhanh nhất về thế giới game hiện nay',
    'lienhe' => 'Liên hệ',
    'typelist' => 'Danh sách thể loại',
    'letter' => 'Phản hồi',
    'nhap' => 'Nhập...',
    'xemthem' => 'Xem thêm',
    'baiviet' => 'Tin tức cùng thể loại',
    'cmt' => 'Bình luận',
    'taocmt' => 'Để lại bình luận',
    'thongbao' => 'Bạn phải đăng nhập hoặc đăng ký để thêm bình luận',
    'dangcmt' => 'Đăng',

];