<?php

return [

    'home' => 'Home',
    'dangnhap' => 'Login/Register',
    'dangxuat' => 'Logout',
    'ngonngu' => 'Language',
    'TA' => 'English',
    'TV' => 'Vienamese',
    'search' => 'Search...',
    'featured' => 'Featured News',
    'popular' => 'Most Popular',
    'hot' => 'Hot News',
    'trending' => 'Trending News',
    'watched' => 'Most Watched',
    'update' => 'News Updates',
    'gioithieu' => 'ABOUT US',
    'gioithieu1' => 'We always bring the most truthful and fastest news about today gaming world',
    'lienhe' => 'CONTACT',
    'typelist' => 'TYPES LIST',
    'letter' => 'GET NEWSLETTER',
    'nhap' => 'Enter text...',
    'xemthem' => 'Read more',
    'baiviet' => 'News of the same type',
    'cmt' => 'Comment',
    'taocmt' => 'Leave a comment',
    'thongbao' => 'You must login or register to add comments',
    'dangcmt' => 'Post a Comment',


];